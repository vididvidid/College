import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
public class Main{

public static void main(String[] arg) throws FileNotFoundException {

 	 File f = new File("sample.txt");
 	
	 Scanner sc = new Scanner(f);

while(sc.hasNext()){

String l1 = sc.nextLine();
System.out.println (l1);
}



}


}